package com.example.my.todo.dto;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.example.my.todo.entity.TodoEntity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class TodoDTO {

    // @Data
    // public static class ReqHello{
    // private Integer idx;
    // private String search;
    // }

    // @Data
    // @Builder
    // @NoArgsConstructor
    // @AllArgsConstructor
    // public static class ResBasic {
    // private Integer idx;
    // private String content;
    // private Character doneYn;
    // }
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResBasic {
        private List<Todo> todoList;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        static class Todo {
            Integer idx;
            String content;
            Character doneYn;

        }

        // 엔티티에서 dto를사용함
        public static ResBasic fromEntityList(List<TodoEntity> todoEntityList) {
            List<Todo> todoList = todoEntityList.stream().map(todoEntity -> {
                return Todo.builder()
                        .idx(todoEntity.getIdx())
                        .content(todoEntity.getContent())
                        .doneYn(todoEntity.getDoneYn())
                        .build();

            }).collect(Collectors.toList());
            return ResBasic.builder().todoList(todoList).build();
        }

    }
}
